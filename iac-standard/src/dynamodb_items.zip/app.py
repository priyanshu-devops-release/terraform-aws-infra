import json
import logging
import os

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

TABLE = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])


def _response(status, body):
    return {"statusCode": status, "body": json.dumps(body, default=str)}


def handler(event, context):
    """Item CRUD against DynamoDB.

    Event examples:
      {"action": "put",    "id": "1", "data": {"name": "laptop"}}
      {"action": "get",    "id": "1"}
      {"action": "delete", "id": "1"}
      {"action": "list"}
    """
    action = event.get("action")
    item_id = event.get("id")
    logger.info("action=%s id=%s", action, item_id)

    try:
        if action == "put":
            TABLE.put_item(Item={"id": item_id, **event.get("data", {})})
            return _response(200, {"message": "item saved", "id": item_id})

        if action == "get":
            item = TABLE.get_item(Key={"id": item_id}).get("Item")
            if item is None:
                return _response(404, {"message": "item not found", "id": item_id})
            return _response(200, item)

        if action == "delete":
            TABLE.delete_item(Key={"id": item_id})
            return _response(200, {"message": "item deleted", "id": item_id})

        if action == "list":
            return _response(200, TABLE.scan(Limit=50).get("Items", []))

        return _response(400, {"message": "action must be one of put, get, delete, list"})

    except ClientError as err:
        # AccessDeniedException here means the execution role is missing a DynamoDB permission
        code = err.response["Error"]["Code"]
        logger.error("DynamoDB %s failed: %s - %s", action, code, err.response["Error"]["Message"])
        status = 403 if code == "AccessDeniedException" else 500
        return _response(status, {"error": code, "message": err.response["Error"]["Message"]})
